#include "sync.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct {Frame f;Item bag[4];int calls,slot,accept,bad,reads;} Fake;
static int frame(void*c,Frame*f){Fake*x=c;*f=x->f;return !x->bad;}
static int source(void*c,Ref r,Item*a,int*i){Fake*x=c;x->reads++;for(int k=0;k<4;k++)if(ref_same(r,x->bag[k].ref)){*a=x->bag[k];*i=k;return 1;}return 0;}
static int use(void*c,int i,int show){Fake*x=c;(void)show;assert(i>=0&&i<4);assert(ammo_matches(x->bag[i],x->f.weapon));assert(!x->bag[i].locked&&!x->f.weapon.locked&&!x->f.ammo.locked);x->calls++;x->slot=i;return x->accept;}
static Item bow={.ref={100,10,15},.ranged=1,.type=1,.grade=10};
static Item sling={.ref={200,20,15},.ranged=1,.type=2,.grade=10};
static Item arrow={.ref={300,30,2},.type=1,.min_grade=1,.max_grade=20,.count=200};
static Item bolt={.ref={400,40,2},.type=2,.min_grade=1,.max_grade=20,.count=200};
static void setup(Sync*s,Fake*f){memset(f,0,sizeof(*f));f->f=(Frame){.owner=1,.player=99,.alive=1,.valid=1,.weapon=bow,.ammo=arrow};f->bag[0]=bolt;f->accept=1;sync_init(s,(SyncOps){frame,source,use,f});}
int main(void){Sync s;Fake f;unsigned passed=0;
 /* Real regression: weapon and ammo requested in one frame, weapon ACK later. */
 setup(&s,&f);sync_weapon_request(&s,&f.f,&sling,0);assert(!sync_request(&s,&f.f,&bolt,0));
 for(unsigned t=0;t<200;t+=15)sync_tick(&s,t);assert(f.calls==0);
 f.f.weapon=sling;sync_tick(&s,210);assert(f.calls==1&&s.flight.object&&s.forwarded==1);
 for(unsigned t=225;t<600;t+=15){assert(!sync_request(&s,&f.f,&bolt,t));sync_tick(&s,t);}assert(f.calls==1);
 f.f.ammo=bolt;sync_tick(&s,600);assert(s.confirmed==1&&!s.flight.object);passed++;
 /* Reverse request order: ammo arrives before the weapon request. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));sync_tick(&s,15);assert(!f.calls);sync_weapon_request(&s,&f.f,&sling,20);f.f.weapon=sling;sync_tick(&s,40);assert(f.calls==1);passed++;
 /* Source slots may move while the server confirms the weapon. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));f.bag[3]=f.bag[0];memset(&f.bag[0],0,sizeof(Item));f.f.weapon=sling;sync_tick(&s,50);assert(f.slot==3&&f.calls==1);passed++;
 /* Same bag slot reused for another item must never be sent. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));f.bag[0].ref.id=1234;f.f.weapon=sling;sync_tick(&s,50);assert(!f.calls&&!s.pending.object);passed++;
 /* Reversing toward DEF cancels the delayed old ammo. */
 setup(&s,&f);sync_weapon_request(&s,&f.f,&sling,0);assert(!sync_request(&s,&f.f,&bolt,0));sync_weapon_request(&s,&f.f,&bow,30);f.f.weapon=sling;sync_tick(&s,50);assert(!f.calls&&!s.pending.object);passed++;
 /* New ammo intent replaces the old intent. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));assert(sync_request(&s,&f.f,&arrow,20));f.f.weapon=sling;sync_tick(&s,100);assert(!f.calls&&!s.pending.object);passed++;
 /* Death, relog, missing memory and timeout all discard stale intent. */
 for(int condition=0;condition<5;condition++){setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));f.f.weapon=sling;if(condition==0)f.f.alive=0;if(condition==1)f.f.owner=2;if(condition==2)f.f.player=100;if(condition==3)f.bad=1;sync_tick(&s,condition==4?3001:50);assert(!f.calls&&!s.pending.object);passed++;}
 /* All three relevant locks are honored. */
 for(int lock=0;lock<3;lock++){setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));f.f.weapon=sling;if(lock==0)f.bag[0].locked=1;if(lock==1)f.f.weapon.locked=1;if(lock==2)f.f.ammo.locked=1;sync_tick(&s,30);assert(!f.calls);f.bag[0].locked=f.f.weapon.locked=f.f.ammo.locked=0;sync_tick(&s,45);assert(f.calls==1);passed++;}
 /* Same subtype, wrong grade: do not relax native equipment requirements. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));f.f.weapon=sling;f.f.weapon.grade=21;sync_tick(&s,15);assert(!f.calls);f.f.weapon.grade=10;sync_tick(&s,30);assert(f.calls==1);passed++;
 /* Native refusal uses bounded retries, not one send per frame. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));f.f.weapon=sling;f.accept=0;for(unsigned t=0;t<1000;t+=5)sync_tick(&s,t);assert(f.calls==10&&!s.flight.object);passed++;
 /* A native-accepted command cannot be replayed on elapsed time alone. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));f.f.weapon=sling;sync_tick(&s,15);f.bag[0].locked=1;for(unsigned t=30;t<10000;t+=15)sync_tick(&s,t);assert(f.calls==1&&s.flight.object);passed++;
 /* Old ACK: new target waits, then validates the new live weapon. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));f.f.weapon=sling;sync_tick(&s,15);f.bag[1]=arrow;assert(!sync_request(&s,&f.f,&arrow,30));sync_weapon_request(&s,&f.f,&bow,40);f.f.weapon=bow;sync_tick(&s,50);assert(f.calls==1);f.f.ammo=bolt;sync_tick(&s,60);assert(f.calls==2&&f.slot==1);passed++;
 /* Melee/unarmed and already compatible requests preserve normal dispatch. */
 setup(&s,&f);assert(sync_request(&s,&f.f,&arrow,0));f.f.weapon.ranged=0;assert(sync_request(&s,&f.f,&bolt,0));assert(!s.pending.object);passed++;
 /* Stack merging changes object identity; confirmed template is sufficient. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0));f.f.weapon=sling;sync_tick(&s,15);f.f.ammo=bolt;f.f.ammo.ref.object=9876;sync_tick(&s,30);assert(s.confirmed==1&&!s.flight.object);passed++;
 /* Unsigned tick wrap must not discard a fresh pending request. */
 setup(&s,&f);assert(!sync_request(&s,&f.f,&bolt,0xfffffff0u));f.f.weapon=sling;sync_tick(&s,20);assert(f.calls==1);passed++;
 /* Exhaustive asynchronous ordering over 1,000 weapon/ACK schedules. */
 for(unsigned delay=0;delay<1000;delay++){setup(&s,&f);sync_weapon_request(&s,&f.f,&sling,0);assert(!sync_request(&s,&f.f,&bolt,0));for(unsigned t=0;t<1300;t+=5){if(t>=delay)f.f.weapon=sling;if(f.calls&&t>=delay+100)f.f.ammo=bolt;sync_tick(&s,t);}assert(f.calls==1&&s.confirmed==1);}passed++;
 printf("PASS: %u scenario groups; 1000 asynchronous schedules; zero incompatible sends.\n",passed);return 0;
}
