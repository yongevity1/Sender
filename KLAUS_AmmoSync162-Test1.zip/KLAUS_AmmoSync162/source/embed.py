from pathlib import Path
import hashlib
p=Path(__file__).resolve().parent
b=(p/'bridge.dll').read_bytes()
tag=hashlib.sha256(b).hexdigest()[:16]
(p/'bridge_payload.h').write_text('#define BRIDGE_TAG L"'+tag+'"\nstatic const unsigned char bridge_payload[]={\n'+','.join(str(x) for x in b)+'\n};\n')
print('Embedded bridge:',len(b),'bytes;',tag)
