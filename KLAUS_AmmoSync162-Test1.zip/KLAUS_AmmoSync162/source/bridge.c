#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <string.h>
#include "shared.h"
#include "sync.h"
#define THISCALL __attribute__((thiscall))
#define AMMO_FASTCALL __attribute__((fastcall))
typedef unsigned char(THISCALL *UseFn)(void*,int,int,int);
static Shared *shared;
static HANDLE mapping;
static Sync engine;
static DWORD game_thread;
static uint32_t generation;
static UINT tick_message;
static UseFn original;
static unsigned char *trampoline;
static int hooked,in_call,pinned;
static const unsigned char original_bytes[8]={0x6a,0xff,0x68,0x20,0x6d,0xd6,0x00,0x64};
static unsigned char hook_bytes[8];
static int readmem(uint32_t a,void*out,SIZE_T n){SIZE_T got=0;return a>=0x10000u&&ReadProcessMemory(GetCurrentProcess(),(void*)(uintptr_t)a,out,n,&got)&&got==n;}
static uint32_t rd32(uint32_t a){uint32_t x=0;readmem(a,&x,4);return x;}
static uint32_t host(void){uint32_t g=rd32(GAME_ROOT),r=rd32(g+0x1c),h=rd32(r+0x30),v=rd32(h);return v>=0x401000u&&v<0x400000u+GAME_IMAGE_SIZE?h:0;}
static int read_item(uint32_t p,Item*out){
 memset(out,0,sizeof(*out));if(!p)return 1;
 uint32_t w[64];if(!readmem(p,w,sizeof(w))||w[0]<0x401000u||w[0]>=0x400000u+GAME_IMAGE_SIZE)return 0;
 out->ref=(Ref){p,w[3],w[2]};out->locked=(w[12]&0xffff0000u)!=0;out->count=(int)w[5];
 if(w[2]==2){
  if(w[0]!=0xe58704u||w[10]!=0x800u||w[11]!=0||!readmem(w[61],&out->type,4))return 0;
  out->min_grade=(int)w[59];out->max_grade=(int)w[60];
 }else if(w[2]==15){out->ranged=(int)(w[56]&0xffffu);out->grade=(int)w[58];out->type=w[59];}
 return 1;
}
static int pointers(uint32_t h,uint32_t offset,uint32_t*p,unsigned*n){
 uint32_t c=rd32(h+offset),v[3];*n=0;
 if(!readmem(c+12,v,12)||v[1]>512u||v[2]<v[1]||v[2]>512u)return 0;
 if(v[1]&&!readmem(v[0],p,v[1]*4u))return 0;*n=v[1];return 1;
}
static int frame(void*ctx,Frame*f){
 (void)ctx;memset(f,0,sizeof(*f));uint32_t h=host(),p[512],id,flags;unsigned n;
 if(!h||!readmem(h+0x4c0,&id,4)||!readmem(h+0x8bc,&flags,4)||!pointers(h,0x13bc,p,&n)||n<12)return 0;
 f->owner=h;f->player=id;f->alive=!(flags&0x80u);
 if(!read_item(p[0],&f->weapon)||!read_item(p[11],&f->ammo))return 0;
 f->valid=1;return 1;
}
static int source(void*ctx,Ref ref,Item*out,int*index){
 (void)ctx;uint32_t h=host(),p[512];unsigned n;
 if(!h||h!=engine.owner||!pointers(h,0x13b8,p,&n))return 0;
 for(unsigned i=0;i<n;i++)if(p[i]==ref.object){
  if(!read_item(p[i],out)||!ref_same(ref,out->ref))return 0;*index=(int)i;return 1;
 }
 return 0;
}
static int native_use(void*ctx,int index,int show){
 (void)ctx;uint32_t h=host();if(!h||h!=engine.owner||GetCurrentThreadId()!=game_thread||!original)return 0;
 in_call=1;int result=original((void*)(uintptr_t)h,0,index,show)!=0;in_call=0;return result;
}
static void publish(void){if(!shared)return;shared->status=engine.status;shared->held=engine.held;shared->forwarded=engine.forwarded;shared->confirmed=engine.confirmed;shared->cancelled=engine.cancelled;}
static int enabled(void){return shared&&shared->magic==AMMO_MAGIC&&shared->build==AMMO_BUILD&&shared->generation==generation&&shared->active&&GetTickCount()-shared->heartbeat<2000u;}
static int exchange_bytes(const unsigned char*from,const unsigned char*to){
 DWORD old=0,restore=0;LONGLONG expected,replacement;memcpy(&expected,from,8);memcpy(&replacement,to,8);
 if(!VirtualProtect((void*)USE_ITEM,8,PAGE_EXECUTE_READWRITE,&old))return 0;
 LONGLONG previous=InterlockedCompareExchange64((volatile LONGLONG*)USE_ITEM,replacement,expected);
 FlushInstructionCache(GetCurrentProcess(),(void*)USE_ITEM,8);
 int protected_ok=VirtualProtect((void*)USE_ITEM,8,old,&restore)!=0;
 if(!protected_ok&&shared)shared->error=4;
 return previous==expected;
}
static void remove_hook(void){
 if(hooked){if(!exchange_bytes(hook_bytes,original_bytes)){if(shared)shared->error=3;return;}hooked=0;}
 sync_cancel(&engine);engine.flight=(Ref){0};if(shared)shared->installed=0;publish();
}
static unsigned char AMMO_FASTCALL use_hook(void*self,void*unused,int kind,int index,int show){
 (void)unused;
 if(!original)return 0;
 if(GetCurrentThreadId()!=game_thread||in_call)return original(self,kind,index,show);
 if(!enabled()){remove_hook();return original(self,kind,index,show);}
 if(kind!=0||index<0)return original(self,kind,index,show);
 Frame f;uint32_t bag[512];unsigned count;Item item;
 if(!frame(0,&f)||f.owner!=(uint32_t)(uintptr_t)self||!f.alive||
    !pointers(f.owner,0x13b8,bag,&count)||(unsigned)index>=count||!read_item(bag[index],&item))
  return original(self,kind,index,show);
 if(item.ref.category==15)sync_weapon_request(&engine,&f,&item,GetTickCount());
 if(item.ref.category==2&&!sync_request(&engine,&f,&item,GetTickCount())){publish();return 0;}
 publish();return original(self,kind,index,show);
}
static int install(void){
 unsigned char got[8];
 if(!readmem(USE_ITEM,got,8)||memcmp(got,original_bytes,8))return 0;
 if(!trampoline){
  trampoline=(unsigned char*)VirtualAlloc(0,32,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
  if(!trampoline)return 0;
  memcpy(trampoline,original_bytes,7);trampoline[7]=0xe9;
  int32_t back=(int32_t)(USE_ITEM+7u-(uint32_t)(uintptr_t)(trampoline+12));memcpy(trampoline+8,&back,4);
  DWORD old;if(!VirtualProtect(trampoline,32,PAGE_EXECUTE_READ,&old))return 0;
  FlushInstructionCache(GetCurrentProcess(),trampoline,12);original=(UseFn)trampoline;
 }
 memcpy(hook_bytes,original_bytes,8);hook_bytes[0]=0xe9;
 int32_t rel=(int32_t)((uint32_t)(uintptr_t)use_hook-(USE_ITEM+5u));memcpy(hook_bytes+1,&rel,4);hook_bytes[5]=hook_bytes[6]=0x90;
 if(!pinned){HMODULE module;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)(uintptr_t)use_hook,&module))return 0;pinned=1;}
 if(!exchange_bytes(original_bytes,hook_bytes))return 0;
 hooked=1;shared->installed=1;return 1;
}
static int connect_shared(void){
 if(shared)return 1;wchar_t name[80];wsprintfW(name,L"Local\\KlausAmmoSync162_%lu",GetCurrentProcessId());
 mapping=OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,name);if(!mapping)return 0;
 shared=(Shared*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared));
 if(!shared){CloseHandle(mapping);mapping=0;return 0;}
 if(shared->magic!=AMMO_MAGIC||shared->build!=AMMO_BUILD||shared->pid!=GetCurrentProcessId())return 0;
 game_thread=shared->thread;generation=shared->generation;tick_message=RegisterWindowMessageW(AMMO_TICK_NAME);sync_init(&engine,(SyncOps){frame,source,native_use,0});return 1;
}
__declspec(dllexport) LRESULT CALLBACK AmmoHook(int code,WPARAM wp,LPARAM lp){
 if(code>=0&&wp==PM_REMOVE&&connect_shared()&&GetCurrentThreadId()==game_thread){
  MSG*m=(MSG*)lp;
  if(m&&!m->hwnd&&m->message==tick_message&&m->wParam==shared->generation){
   m->message=WM_NULL;
   if(generation!=shared->generation){remove_hook();generation=shared->generation;sync_init(&engine,(SyncOps){frame,source,native_use,0});}
   if(!enabled())remove_hook();
   else if(!hooked){if(!shared->error&&!install()){shared->error=1;shared->active=0;}}
   else {sync_tick(&engine,GetTickCount());publish();}
   shared->ack=(uint32_t)m->lParam;
  }
 }
 return CallNextHookEx(0,code,wp,lp);
}
BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,LPVOID reserved){(void)reserved;if(reason==DLL_PROCESS_ATTACH)DisableThreadLibraryCalls(h);return TRUE;}
