@echo off
setlocal
cd /d "%~dp0"
zig cc -target x86-windows-gnu -O2 -std=c11 -Wall -Wextra -Werror -shared bridge.c sync.c -o bridge.dll -luser32 -lkernel32
if errorlevel 1 exit /b 1
python embed.py
if errorlevel 1 exit /b 1
zig cc -target x86-windows-gnu -O2 -std=c11 -Wall -Wextra -Werror -municode -Wl,--subsystem,windows panel.c -o ..\KLAUS_AmmoSync162.exe -luser32 -lgdi32 -lbcrypt -lkernel32
if errorlevel 1 exit /b 1
