#ifndef AMMO_SHARED_H
#define AMMO_SHARED_H
#include <stdint.h>
#define AMMO_MAGIC 0x4b413631u
#define AMMO_BUILD 1u
#define GAME_ROOT 0x107599cu
#define GAME_IMAGE_SIZE 0xcd4000u
#define USE_ITEM 0x4f0c60u
#define AMMO_TICK_NAME L"Klaus.AmmoSync162.Tick.v1"
typedef struct {
 uint32_t magic,build,pid,controller,thread,window,generation;
 volatile int32_t active,installed,error,status;
 volatile uint32_t heartbeat,held,forwarded,confirmed,cancelled;
 volatile uint32_t sequence,ack;
} Shared;
#endif
