"""Execute the actual built bridge and original client prologue in Unicorn.
Windows APIs and the server are modeled; this is not a live game test.
Usage: python test_bridge_binary.py path/to/elementclient.exe
Requires pefile, capstone and unicorn.
"""
from pathlib import Path
import struct,sys,hashlib
import pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_32
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *

root=Path(__file__).resolve().parent
client=Path(sys.argv[1])
assert hashlib.sha256(client.read_bytes()).hexdigest()=='fb4959bbf95e0ddeb9ae93e6c60fb9160caa4efd03ba9cf1614b433ffaa35005'
u=Uc(UC_ARCH_X86,UC_MODE_32)
def map_pe(path):
    p=pefile.PE(path);base=p.OPTIONAL_HEADER.ImageBase
    u.mem_map(base,(p.OPTIONAL_HEADER.SizeOfImage+4095)&~4095)
    u.mem_write(base,p.get_memory_mapped_image());return p
game=map_pe(client);dll=map_pe(root/'bridge.dll')
for at,size in [(0x20000000,0x100000),(0x30000000,0x10000),(0x60000000,0x10000),(0x70000000,0x10000)]:u.mem_map(at,size)
def put(a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
def get(a):return struct.unpack('<I',u.mem_read(a,4))[0]
SH=0x20000000;MSG=0x20001000;HOST=0x20010000;BAG=0x20020000;EQ=0x20021000;BAGPTR=0x20022000;EQPTR=0x20023000
BOW=0x20030000;SLING=0x20031000;ARROW=0x20032000;BOLT=0x20033000
put(0x107599c,0x20040000);put(0x2004001c,0x20041000);put(0x20041030,HOST)
put(HOST,0xe40000);put(HOST+0x4c0,99);put(HOST+0x13b8,BAG);put(HOST+0x13bc,EQ)
for c,p,n in [(BAG,BAGPTR,4),(EQ,EQPTR,39)]:
    for off,v in [(12,p),(16,n),(20,n)]:put(c+off,v)
def weapon(p,id,kind):
    for off,v in [(0,0xe50000),(8,15),(12,id),(20,1),(40,1),(0xe0,1),(0xe8,10),(0xec,kind)]:put(p+off,v)
def ammo(p,id,kind):
    for off,v in [(0,0xe58704),(8,2),(12,id),(20,200),(40,0x800),(0xec,1),(0xf0,20),(0xf4,p+0x200)]:put(p+off,v)
    put(p+0x200,kind)
weapon(BOW,10,1);weapon(SLING,20,2);ammo(ARROW,30,1);ammo(BOLT,40,2)
put(BAGPTR,BOLT);put(BAGPTR+4,SLING);put(EQPTR,BOW);put(EQPTR+44,ARROW)
for off,v in [(0,0x4b413631),(4,1),(8,123),(12,456),(16,222),(20,999),(24,1),(28,1)]:put(SH+off,v)
state={'now':100,'calls':[],'alloc':0x30000000}
apis={};next_api=0x70000000
for lib in dll.DIRECTORY_ENTRY_IMPORT:
    for imp in lib.imports:
        name=imp.name.decode() if imp.name else str(imp.ordinal)
        apis[next_api]=name;put(imp.address,next_api);u.mem_write(next_api,b'\xc3');next_api+=16
def api_return(value,nargs):
    sp=u.reg_read(UC_X86_REG_ESP);ret=get(sp)
    u.reg_write(UC_X86_REG_EAX,value&0xffffffff);u.reg_write(UC_X86_REG_ESP,sp+4+nargs*4);u.reg_write(UC_X86_REG_EIP,ret)
def callback(uc,address,size,unused):
    if address==0x4f0c67:
        sp=u.reg_read(UC_X86_REG_ESP)
        assert get(sp)==0xd66d20 and get(sp+4)==0xffffffff
        assert u.reg_read(UC_X86_REG_ECX)==HOST
        kind,index,show=(get(sp+x) for x in [12,16,20])
        state['calls'].append((kind,index,show))
        ret=get(sp+8);u.reg_write(UC_X86_REG_EAX,1);u.reg_write(UC_X86_REG_ESP,sp+24);u.reg_write(UC_X86_REG_EIP,ret);return
    if address not in apis:return
    name=apis[address];sp=u.reg_read(UC_X86_REG_ESP)
    arg=lambda i:get(sp+4+i*4)
    if name=='ReadProcessMemory':
        try:u.mem_write(arg(2),bytes(u.mem_read(arg(1),arg(3))));put(arg(4),arg(3));api_return(1,5)
        except Exception:api_return(0,5)
    elif name=='GetCurrentProcess':api_return(0xffffffff,0)
    elif name=='GetCurrentProcessId':api_return(123,0)
    elif name=='GetCurrentThreadId':api_return(222,0)
    elif name=='GetTickCount':api_return(state['now'],0)
    elif name=='OpenFileMappingW':api_return(1,3)
    elif name=='MapViewOfFile':api_return(SH,5)
    elif name=='RegisterWindowMessageW':api_return(0xc123,1)
    elif name=='CallNextHookEx':api_return(0,4)
    elif name=='wsprintfW':u.mem_write(arg(0),'mapping'.encode('utf-16le')+b'\0\0');api_return(7,0)
    elif name=='VirtualAlloc':
        p=state['alloc'];state['alloc']+=0x1000;api_return(p,4)
    elif name=='VirtualProtect':put(arg(3),0x20);api_return(1,4)
    elif name=='FlushInstructionCache':api_return(1,3)
    elif name=='GetModuleHandleExW':put(arg(2),dll.OPTIONAL_HEADER.ImageBase);api_return(1,3)
    else:raise AssertionError('Unexpected API '+name)
u.hook_add(UC_HOOK_CODE,callback)
STOP=0x7000f000;u.mem_write(STOP,b'\xcc')
def call(addr,args=(),ecx=0,callee=True):
    sp=0x6000e000;put(sp,STOP)
    for i,v in enumerate(args):put(sp+4+i*4,v)
    for reg,v in [(UC_X86_REG_ESP,sp),(UC_X86_REG_ECX,ecx),(UC_X86_REG_EBX,0x12345678),(UC_X86_REG_ESI,0x23456789),(UC_X86_REG_EDI,0x3456789a),(UC_X86_REG_EBP,0x456789ab)]:u.reg_write(reg,v)
    u.emu_start(addr,STOP,count=500000)
    assert u.reg_read(UC_X86_REG_EIP)==STOP,'did not return'
    assert u.reg_read(UC_X86_REG_ESP)==sp+4+4*len(args),'bad stack cleanup'
    for reg,v in [(UC_X86_REG_EBX,0x12345678),(UC_X86_REG_ESI,0x23456789),(UC_X86_REG_EDI,0x3456789a),(UC_X86_REG_EBP,0x456789ab)]:assert u.reg_read(reg)==v,'callee-saved register changed'
    return u.reg_read(UC_X86_REG_EAX)&255
hook=dll.OPTIONAL_HEADER.ImageBase+dll.DIRECTORY_ENTRY_EXPORT.symbols[0].address
def tick(now):
    state['now']=now;put(SH+44,now)
    seq=get(SH+64)+1;put(SH+64,seq)
    for off,v in [(0,0),(4,0xc123),(8,get(SH+24)),(12,seq)]:put(MSG+off,v)
    call(hook,[0,1,MSG]);assert get(SH+68)==seq;assert get(MSG+4)==0
original=bytes(u.mem_read(0x4f0c60,8))
assert [i.size for i in Cs(CS_ARCH_X86,CS_MODE_32).disasm(original[:7],0x4f0c60)]==[2,5]
tick(100);assert get(SH+32)==1 and get(SH+36)==0
assert call(0x4f0c60,[0,0,1],HOST)==0 and not state['calls']
assert call(0x4f0c60,[0,1,1],HOST)==1 and state['calls']==[(0,1,1)]
tick(120);assert len(state['calls'])==1
put(EQPTR,SLING);put(BAGPTR+4,BOW);tick(150)
assert state['calls']==[(0,1,1),(0,0,0)] and get(SH+52)==1
assert call(0x4f0c60,[0,0,1],HOST)==0 and len(state['calls'])==2
put(EQPTR+44,BOLT);put(BAGPTR,ARROW);tick(180);assert get(SH+56)==1
put(SH+28,0);tick(200);assert bytes(u.mem_read(0x4f0c60,8))==original and get(SH+32)==0
assert call(0x4f0c60,[0,0,1],HOST)==1
put(SH+28,1);tick(250);assert get(SH+32)==1
state['now']=3000 # Simulate controller crash: no heartbeat or hook messages.
assert call(0x4f0c60,[0,0,1],HOST)==1
assert bytes(u.mem_read(0x4f0c60,8))==original and get(SH+32)==0
put(SH+24,get(SH+24)+1);tick(3100);assert get(SH+32)==1
put(SH+28,0);tick(3150);assert bytes(u.mem_read(0x4f0c60,8))==original
print('PASS: built x86 DLL executed; install, deferred ammo, weapon ACK, no duplicate, ammo ACK, OFF restore, crash heartbeat, reconnect; stack and callee-saved registers preserved.')
