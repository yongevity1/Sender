#include "sync.h"
#include <string.h>
int ref_same(Ref a,Ref b){return a.object&&a.object==b.object&&a.id==b.id&&a.category==b.category;}
int ammo_matches(Item a,Item w){return a.ref.category==2&&w.ranged==1&&a.type&&a.type==w.type&&w.grade>=a.min_grade&&w.grade<=a.max_grade;}
void sync_init(Sync*s,SyncOps ops){memset(s,0,sizeof(*s));s->ops=ops;}
void sync_cancel(Sync*s){if(s->pending.object)s->cancelled++;s->pending=(Ref){0};s->wanted_known=0;s->has_try=0;s->status=CANCELLED;}
static void clear_all(Sync*s){sync_cancel(s);s->flight=(Ref){0};s->unlocked_seen=0;s->owner=s->player=0;}
static int identity(Sync*s,const Frame*f){
 if(!f->valid||!f->alive||!f->owner||!f->player){clear_all(s);return 0;}
 if(s->owner&&(s->owner!=f->owner||s->player!=f->player))clear_all(s);
 s->owner=f->owner;s->player=f->player;return 1;
}
static int observe_flight(Sync*s,const Frame*f,uint32_t now){
 if(!s->flight.object)return 0;
 if(f->ammo.ref.id==s->flight.id&&f->ammo.ref.category==2&&f->ammo.count>0){
  s->flight=(Ref){0};s->unlocked_seen=0;s->confirmed++;s->status=CONFIRMED;return 0;
 }
 Item it;int slot;
 if(now-s->flight_at>=6250u&&s->ops.source(s->ops.ctx,s->flight,&it,&slot)&&!it.locked&&!f->ammo.locked){
  if(!s->unlocked_seen){s->unlocked_seen=1;s->unlocked_at=now;}
  else if(now-s->unlocked_at>=250u){s->flight=(Ref){0};s->unlocked_seen=0;return 0;}
 }else s->unlocked_seen=0;
 return 1;
}
void sync_weapon_request(Sync*s,const Frame*f,const Item*w,uint32_t now){
 if(!identity(s,f))return;
 s->wanted_weapon=w->ref;s->wanted_known=1;s->weapon_at=now;
 if(s->pending.object){Item a;int index;
  if(!s->ops.source(s->ops.ctx,s->pending,&a,&index)||!ammo_matches(a,*w))sync_cancel(s);
 }
}
int sync_request(Sync*s,const Frame*f,const Item*a,uint32_t now){
 if(!identity(s,f))return 1;
 int inflight=observe_flight(s,f,now);
 if(a->ref.category!=2||!a->ref.object||a->count<=0)return 1;
 if(inflight&&ref_same(a->ref,s->flight))return 0;
 if(!inflight&&f->weapon.ranged!=1){sync_cancel(s);s->status=IDLE;return 1;}
 /* A current compatible request supersedes an older deferred intent. */
 if(!inflight&&ammo_matches(*a,f->weapon)&&!f->weapon.locked){sync_cancel(s);s->status=IDLE;return 1;}
 if(!ref_same(s->pending,a->ref)){
  if(s->pending.object)s->cancelled++;
  s->pending=a->ref;s->started=now;s->has_try=0;s->held++;
 }
 if(s->wanted_known&&now-s->weapon_at>3000u)s->wanted_known=0;
 s->status=WAIT_WEAPON;return 0;
}
void sync_tick(Sync*s,uint32_t now){
 if(!s->pending.object&&!s->flight.object)return;
 Frame f;if(!s->ops.frame(s->ops.ctx,&f)){clear_all(s);s->status=READ_FAILED;return;}
 if(!identity(s,&f))return;
 int inflight=observe_flight(s,&f,now);
 if(!s->pending.object)return;
 if(now-s->started>3000u){sync_cancel(s);return;}
 if(inflight)return;
 Item a;int slot;
 if(!s->ops.source(s->ops.ctx,s->pending,&a,&slot)||a.count<=0){sync_cancel(s);return;}
 if(f.ammo.ref.id==a.ref.id&&f.ammo.ref.category==2&&f.ammo.count>0){s->pending=(Ref){0};s->status=CONFIRMED;return;}
 if(s->wanted_known&&!ref_same(f.weapon.ref,s->wanted_weapon)){s->status=WAIT_WEAPON;return;}
 if(!ammo_matches(a,f.weapon)){s->status=WAIT_WEAPON;return;}
 if(a.locked||f.ammo.locked||f.weapon.locked){s->status=WAIT_LOCK;return;}
 if(s->has_try&&now-s->last_try<100u)return;
 s->has_try=1;s->last_try=now;
 if(s->ops.use(s->ops.ctx,slot,0)){
  s->flight=a.ref;s->flight_at=now;s->unlocked_seen=0;
  s->pending=(Ref){0};s->forwarded++;s->status=SENT;
 }
}
