#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <bcrypt.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "shared.h"
#include "bridge_payload.h"
#define ID_REFRESH 100
#define ID_ACTIVE 101
typedef struct {DWORD pid,thread;HWND window;wchar_t path[1024],label[100];} Client;
static Client clients[64];static unsigned count;
static HWND win,combo,refresh,active,status_text,counters;
static HFONT font,bold;static HBRUSH bg,control_bg;
static HANDLE mapping,process,owner_mutex;static Shared*shared;static HHOOK hook;static HMODULE dll;
static HWND game_window;static DWORD stop_at,attach_at;static int stopping,closing;
static UINT tick_message;static DWORD last_ui;
static int read_remote(HANDLE p,uint32_t at,void*out,SIZE_T size){SIZE_T got=0;return at>=0x10000u&&ReadProcessMemory(p,(void*)(uintptr_t)at,out,size,&got)&&got==size;}
static uint32_t remote32(HANDLE p,uint32_t a){uint32_t v=0;read_remote(p,a,&v,4);return v;}
static void status(const wchar_t*s){SetWindowTextW(status_text,s);}
static int hash_file(const wchar_t*path,unsigned char digest[32]){
 HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
 if(f==INVALID_HANDLE_VALUE)return 0;
 BCRYPT_ALG_HANDLE alg=0;BCRYPT_HASH_HANDLE hash=0;int ok=0;unsigned char buffer[32768];DWORD got;
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,0,0)<0)goto done;
 if(BCryptCreateHash(alg,&hash,0,0,0,0,0)<0)goto done;
 for(;;){if(!ReadFile(f,buffer,sizeof(buffer),&got,0))goto done;if(!got)break;if(BCryptHashData(hash,buffer,got,0)<0)goto done;}
 ok=BCryptFinishHash(hash,digest,32,0)>=0;
 done:if(hash)BCryptDestroyHash(hash);if(alg)BCryptCloseAlgorithmProvider(alg,0);CloseHandle(f);return ok;
}
static int supported(const Client*c){
 static const unsigned char sha[32]={0xfb,0x49,0x59,0xbb,0xf9,0x5e,0x0d,0xde,0xb9,0xae,0x93,0xe6,0xc6,0x0f,0xb9,0x16,0x0c,0xaa,0x4e,0xfd,0x03,0xba,0x9c,0xf1,0x61,0x4b,0x43,0x3f,0xfa,0xa3,0x50,0x05};
 unsigned char actual[32];return hash_file(c->path,actual)&&!memcmp(sha,actual,32);
}
static BOOL CALLBACK enumerate(HWND w,LPARAM unused){
 (void)unused;if(count>=64||!IsWindowVisible(w)||GetWindow(w,GW_OWNER))return TRUE;
 DWORD pid,tid=GetWindowThreadProcessId(w,&pid);if(!pid||pid==GetCurrentProcessId())return TRUE;
 for(unsigned i=0;i<count;i++)if(clients[i].pid==pid)return TRUE;
 HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,pid);if(!p)return TRUE;
 Client c;memset(&c,0,sizeof(c));DWORD len=1024;
 if(!QueryFullProcessImageNameW(p,0,c.path,&len)){CloseHandle(p);return TRUE;}
 wchar_t*name=wcsrchr(c.path,L'\\');name=name?name+1:c.path;
 if(_wcsicmp(name,L"elementclient.exe")){CloseHandle(p);return TRUE;}
 uint32_t pe=remote32(p,0x40003c),image=remote32(p,0x400000+pe+0x50);
 if(image!=GAME_IMAGE_SIZE){CloseHandle(p);return TRUE;}
 c.pid=pid;c.thread=tid;c.window=w;
 uint32_t h=remote32(p,remote32(p,remote32(p,GAME_ROOT)+0x1c)+0x30),ptr=remote32(p,h+0x830);
 wchar_t nick[64]={0};int valid=0;
 if(ptr){for(unsigned k=0;k<63;k++){if(!read_remote(p,ptr+k*2,&nick[k],2))break;if(!nick[k]){valid=k>0;break;}}}
 if(valid)swprintf(c.label,100,L"%ls",nick);else swprintf(c.label,100,L"Client 162 | %lu",pid);
 clients[count++]=c;CloseHandle(p);return TRUE;
}
static void reload(void){
 count=0;SendMessageW(combo,CB_RESETCONTENT,0,0);EnumWindows(enumerate,0);
 for(unsigned i=0;i<count;i++)SendMessageW(combo,CB_ADDSTRING,0,(LPARAM)clients[i].label);
 if(count){SendMessageW(combo,CB_SETCURSEL,0,0);status(L"Pilih karakter, lalu klik Aktifkan.");}
 else status(L"Client 162 belum ditemukan. Buka game lalu Refresh.");
}
static int ensure_bridge(wchar_t path[1024]){
 wchar_t root[800];DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",root,800);if(!n||n>=800)return 0;
 swprintf(path,1024,L"%ls\\Klaus",root);CreateDirectoryW(path,0);
 swprintf(path,1024,L"%ls\\Klaus\\AmmoSync162",root);CreateDirectoryW(path,0);
 swprintf(path,1024,L"%ls\\Klaus\\AmmoSync162\\bridge-%ls.dll",root,BRIDGE_TAG);
 HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
 if(f!=INVALID_HANDLE_VALUE){
  LARGE_INTEGER size;int ok=GetFileSizeEx(f,&size)&&size.QuadPart==(LONGLONG)sizeof(bridge_payload);unsigned char buf[8192];size_t off=0;
  while(ok&&off<sizeof(bridge_payload)){DWORD got=0,want=(DWORD)(sizeof(bridge_payload)-off);if(want>sizeof(buf))want=sizeof(buf);if(!ReadFile(f,buf,want,&got,0)||got!=want||memcmp(buf,bridge_payload+off,want))ok=0;off+=want;}
  CloseHandle(f);return ok;
 }
 f=CreateFileW(path,GENERIC_WRITE,0,0,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE)return 0;
 DWORD wrote=0;int ok=WriteFile(f,bridge_payload,sizeof(bridge_payload),&wrote,0)&&wrote==sizeof(bridge_payload);CloseHandle(f);if(!ok)DeleteFileW(path);return ok;
}
static void detach(void){
 if(shared)shared->active=0;
 if(hook)UnhookWindowsHookEx(hook);hook=0;
 if(shared)UnmapViewOfFile(shared);shared=0;
 if(mapping)CloseHandle(mapping);mapping=0;
 if(process)CloseHandle(process);process=0;
 if(owner_mutex)CloseHandle(owner_mutex);owner_mutex=0;
 if(dll)FreeLibrary(dll);dll=0;game_window=0;stopping=0;
 EnableWindow(combo,TRUE);EnableWindow(refresh,TRUE);EnableWindow(active,TRUE);SetWindowTextW(active,L"Aktifkan");
}
static void begin_stop(void){if(!shared)return;shared->active=0;shared->heartbeat=GetTickCount();stopping=1;stop_at=GetTickCount();status(L"Menonaktifkan dan membatalkan antrean...");EnableWindow(active,FALSE);}
static void attach(void){
 LRESULT index=SendMessageW(combo,CB_GETCURSEL,0,0);if(index<0||(unsigned)index>=count){status(L"Pilih client terlebih dahulu.");return;}
 Client*c=&clients[index];if(!supported(c)){status(L"Client berbeda. Build ini khusus 162 Dominator biasa.");return;}
 process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,c->pid);
 if(!process){status(L"Akses ditolak. Jalankan app setingkat dengan game.");return;}
 wchar_t name[100];swprintf(name,100,L"Local\\KlausAmmoSync162_Owner_%lu",c->pid);
 owner_mutex=CreateMutexW(0,FALSE,name);if(!owner_mutex||GetLastError()==ERROR_ALREADY_EXISTS){detach();status(L"Client ini sudah terhubung ke Ammo Sync lain.");return;}
 swprintf(name,100,L"Local\\KlausAmmoSync162_%lu",c->pid);
 mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,sizeof(Shared),name);
 if(!mapping){detach();status(L"Tidak dapat menyiapkan koneksi.");return;}
 shared=(Shared*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared));
 if(!shared){detach();status(L"Tidak dapat membuka koneksi.");return;}
 shared->active=0;MemoryBarrier();
 uint32_t generation=shared->generation+1u;if(!generation)generation=1;
 memset(shared,0,sizeof(*shared));shared->magic=AMMO_MAGIC;shared->build=AMMO_BUILD;shared->pid=c->pid;shared->controller=GetCurrentProcessId();shared->thread=c->thread;shared->window=(uint32_t)(uintptr_t)c->window;shared->generation=generation;
 wchar_t path[1024];if(!ensure_bridge(path)){detach();status(L"Komponen aplikasi tidak dapat disiapkan.");return;}
 dll=LoadLibraryW(path);if(!dll){detach();status(L"Komponen aplikasi gagal dimuat.");return;}
 HOOKPROC proc=(HOOKPROC)GetProcAddress(dll,"AmmoHook");if(!proc)proc=(HOOKPROC)GetProcAddress(dll,"AmmoHook@12");
 if(!proc){detach();status(L"Komponen aplikasi tidak sesuai.");return;}
 hook=SetWindowsHookExW(WH_GETMESSAGE,proc,dll,c->thread);
 if(!hook){detach();status(L"Koneksi ditolak. Jalankan app setingkat dengan game.");return;}
 game_window=c->window;shared->heartbeat=GetTickCount();shared->active=1;attach_at=GetTickCount();
 EnableWindow(combo,FALSE);EnableWindow(refresh,FALSE);SetWindowTextW(active,L"Nonaktifkan");status(L"Menghubungkan ke karakter...");
}
static void tick(void){
 if(!shared)return;DWORD now=GetTickCount();shared->heartbeat=now;
 if(shared->sequence==shared->ack){uint32_t seq=shared->sequence+1u;shared->sequence=seq;MemoryBarrier();if(!PostThreadMessageW(shared->thread,tick_message,shared->generation,(LPARAM)seq))shared->sequence=shared->ack;}
 if(WaitForSingleObject(process,0)==WAIT_OBJECT_0||!IsWindow(game_window)){detach();status(L"Client ditutup. Pilih client dan aktifkan kembali.");if(closing)DestroyWindow(win);return;}
 if(stopping){if(!shared->installed||now-stop_at>2000u){int clean=!shared->installed;detach();status(clean?L"Nonaktif. Antrean dibatalkan.":L"Nonaktif. Pemulihan selesai pada aksi item berikutnya.");if(closing)DestroyWindow(win);}return;}
 if(now-last_ui<100u)return;last_ui=now;
 if(shared->error){status(L"Koneksi tidak cocok / berubah. Nonaktifkan aplikasi.");shared->active=0;return;}
 if(!shared->installed){if(now-attach_at>4000u){begin_stop();}return;}
 static const wchar_t*states[]={L"Aktif - menunggu swap amunisi.",L"Aktif - menunggu senjata yang cocok.",L"Aktif - menunggu slot amunisi siap.",L"Aktif - amunisi dikirim, menunggu konfirmasi.",L"Aktif - amunisi terpasang.",L"Aktif - antrean lama dibatalkan.",L"Aktif - data berubah, antrean dibatalkan."};
 unsigned s=(unsigned)shared->status;status(s<7?states[s]:states[0]);
 wchar_t text[120];swprintf(text,120,L"Ditahan %lu   Dikirim %lu   Terpasang %lu",shared->held,shared->forwarded,shared->confirmed);SetWindowTextW(counters,text);
}
static HWND child(const wchar_t*cls,const wchar_t*text,DWORD style,int x,int y,int w,int h,int id){HWND c=CreateWindowExW(0,cls,text,WS_CHILD|WS_VISIBLE|style,x,y,w,h,win,(HMENU)(INT_PTR)id,GetModuleHandleW(0),0);SendMessageW(c,WM_SETFONT,(WPARAM)font,TRUE);return c;}
static LRESULT CALLBACK procedure(HWND w,UINT m,WPARAM wp,LPARAM lp){
 switch(m){
 case WM_CREATE:{win=w;HWND title=child(L"STATIC",L"AMMO SYNC 162",0,18,16,310,26,0);SendMessageW(title,WM_SETFONT,(WPARAM)bold,TRUE);child(L"STATIC",L"Pendamping swap senjata & amunisi",0,18,46,310,21,0);
  combo=child(L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,18,79,231,180,0);refresh=child(L"BUTTON",L"Refresh",BS_OWNERDRAW|WS_TABSTOP,257,79,83,26,ID_REFRESH);
  active=child(L"BUTTON",L"Aktifkan",BS_OWNERDRAW|WS_TABSTOP,18,120,322,34,ID_ACTIVE);status_text=child(L"STATIC",L"",0,18,169,322,43,0);counters=child(L"STATIC",L"Ditahan 0   Dikirim 0   Terpasang 0",0,18,215,322,20,0);
  child(L"STATIC",L"Test 1                              By MSRxKlaus",0,18,251,322,20,0);SetTimer(w,1,15,0);reload();return 0;}
 case WM_COMMAND:if(HIWORD(wp)==BN_CLICKED){if(LOWORD(wp)==ID_REFRESH)reload();if(LOWORD(wp)==ID_ACTIVE){if(shared)begin_stop();else attach();}}return 0;
 case WM_TIMER:if(wp==1)tick();return 0;
 case WM_CTLCOLORSTATIC:case WM_CTLCOLORLISTBOX:{HDC dc=(HDC)wp;SetTextColor(dc,RGB(229,229,235));SetBkColor(dc,RGB(22,22,27));return (LRESULT)bg;}
 case WM_DRAWITEM:{DRAWITEMSTRUCT*d=(DRAWITEMSTRUCT*)lp;if(d->CtlType!=ODT_BUTTON)break;int disabled=(d->itemState&ODS_DISABLED)!=0;HBRUSH b=CreateSolidBrush(disabled?RGB(55,40,44):(d->CtlID==ID_ACTIVE?RGB(156,29,47):RGB(55,45,52)));FillRect(d->hDC,&d->rcItem,b);DeleteObject(b);SetBkMode(d->hDC,TRANSPARENT);SetTextColor(d->hDC,disabled?RGB(130,120,125):RGB(255,245,247));wchar_t text[80];GetWindowTextW(d->hwndItem,text,80);SelectObject(d->hDC,font);DrawTextW(d->hDC,text,-1,&d->rcItem,DT_CENTER|DT_VCENTER|DT_SINGLELINE);if(d->itemState&ODS_FOCUS){RECT r=d->rcItem;InflateRect(&r,-3,-3);DrawFocusRect(d->hDC,&r);}return TRUE;}
 case WM_CLOSE:if(shared){closing=1;begin_stop();}else DestroyWindow(w);return 0;
 case WM_DESTROY:KillTimer(w,1);detach();PostQuitMessage(0);return 0;
 }
 return DefWindowProcW(w,m,wp,lp);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE prev,LPWSTR args,int show){
 (void)prev;(void)args;SetProcessDPIAware();tick_message=RegisterWindowMessageW(AMMO_TICK_NAME);if(!tick_message)return 1;bg=CreateSolidBrush(RGB(22,22,27));control_bg=CreateSolidBrush(RGB(32,32,38));
 font=CreateFontW(-14,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");bold=CreateFontW(-18,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
 WNDCLASSW cls={0};cls.lpfnWndProc=procedure;cls.hInstance=instance;cls.hCursor=LoadCursorW(0,IDC_ARROW);cls.hbrBackground=bg;cls.lpszClassName=L"KlausAmmoSync162";cls.hIcon=LoadIconW(0,IDI_APPLICATION);RegisterClassW(&cls);
 RECT rc={0,0,358,288};DWORD style=WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;AdjustWindowRect(&rc,style,FALSE);
 HWND w=CreateWindowExW(0,cls.lpszClassName,L"AMMO SYNC 162",style,CW_USEDEFAULT,CW_USEDEFAULT,rc.right-rc.left,rc.bottom-rc.top,0,0,instance,0);
 if(!w)return 1;ShowWindow(w,show);UpdateWindow(w);MSG msg;int result;
 while((result=GetMessageW(&msg,0,0,0))>0){if(!IsDialogMessageW(w,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}}
 DeleteObject(font);DeleteObject(bold);DeleteObject(control_bg);DeleteObject(bg);return result<0?1:(int)msg.wParam;
}
