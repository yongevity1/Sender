#ifndef AMMO_SYNC_H
#define AMMO_SYNC_H
#include <stdint.h>
typedef struct { uint32_t object,id,category; } Ref;
typedef struct { Ref ref; uint32_t type; int ranged,grade,min_grade,max_grade,locked,count; } Item;
typedef struct { uint32_t owner,player; int alive,valid; Item weapon,ammo; } Frame;
typedef struct {
 int (*frame)(void*,Frame*);
 int (*source)(void*,Ref,Item*,int*);
 int (*use)(void*,int,int);
 void *ctx;
} SyncOps;
enum { IDLE,WAIT_WEAPON,WAIT_LOCK,SENT,CONFIRMED,CANCELLED,READ_FAILED };
typedef struct {
 SyncOps ops; Ref pending,flight,wanted_weapon; uint32_t owner,player;
 uint32_t started,flight_at,unlocked_at,weapon_at,last_try;
 int has_try,unlocked_seen,wanted_known,status;
 uint32_t held,forwarded,confirmed,cancelled;
} Sync;
void sync_init(Sync*,SyncOps);
void sync_cancel(Sync*);
int ref_same(Ref,Ref);
int ammo_matches(Item,Item);
/* Returns 1 to call the native function immediately, 0 when held. */
int sync_request(Sync*,const Frame*,const Item*,uint32_t);
void sync_weapon_request(Sync*,const Frame*,const Item*,uint32_t);
void sync_tick(Sync*,uint32_t);
#endif
